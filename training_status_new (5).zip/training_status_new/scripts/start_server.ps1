# Start dashboard + upload API (saves files under trainings/*/uploads/)
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root

if (-not (Test-Path ".venv\Scripts\python.exe")) {
    python -m venv .venv
    .\.venv\Scripts\pip install -r requirements.txt
}

.\.venv\Scripts\python.exe scripts\ensure_upload_folders.py
.\.venv\Scripts\python.exe server\upload_server.py
