# Training calculation steps

This document describes **exactly** what happens when you click **Calculate** in the HTML dashboard (`dashboard/index.html`) or run the Python tool (`tool/run_calculation.py`). Both use the same rules (JavaScript in `shared/javascript/app.js`, Python in `shared/python/dashboard_calculators.py`).

## How to run (no localhost required)

### Option A — HTML dashboard (browser only)

1. Open **`dashboard/index.html`** in Chrome or Edge (double-click or drag into the browser).
2. On each tab, upload the Excel file(s) for that training.
3. Set **Assignment Date** if the training uses it.
4. Click **Calculate**.
5. Use **Download Updated Userbase** (userbase trainings) or **Download Excel** (tool-only trainings).

Files stay in the browser memory unless you download the result. Nothing is uploaded to a server.

### Option B — Python + SQLite (CLI)

```powershell
cd c:\Users\manka\Downloads\training_status_new
pip install -r requirements.txt

# List trainings
python tool/run_calculation.py --list

# Example: BSC
python tool/run_calculation.py bsc ^
  --base trainings\bsc\input\userbase.xlsx ^
  --tool trainings\bsc\input\BSC.xlsx ^
  --assign-date 2026-05-29

# View run history
python tool/run_calculation.py --history
```

- **Output Excel:** `trainings/<module>/output/<module>_Updated_Userbase_YYYY-MM-DD.xlsx` (or `_Output_` for tool-only).
- **SQLite:** `data/training_status.db`
  - Table **`calculation_runs`** — each CLI run (counts, file paths, timestamp).
  - Table **`completion_records`** — used by legacy CLI scripts for inferred completion dates when LMS date is missing.

---

## Shared preprocessing (all trainings)

| Step | Action |
|------|--------|
| 1 | Read the **first worksheet** of each uploaded `.xlsx`. |
| 2 | **Tool / LMS file:** find the header row containing **Employee ID**, **Transcript Status**, and **Work Email Address** (usually Excel row 22; scanned up to ~35 rows). |
| 3 | **Userbase file:** find the first row with both an **email** column and an **employee id** column (header usually row 1). |
| 4 | Drop rows where **Employee Status** = `Terminated` (if that column exists). |
| 5 | **Deduplicate** output rows by normalized email, else by normalized employee ID (first row wins). |

**Normalization:** emails → lowercase trim; employee IDs → trim, strip trailing `.0` from Excel numbers.

**Status mapping (tool rows):**

- If completion date is present → **Completed**
- Else if transcript status contains “in progress” → **In Progress**
- Else use LMS transcript status, or **Not Started** if empty

**Zone:** from tool **Macro Entity Level 2 (Zone)** or **Zone**, with macro mapping (e.g. `ZONE EUROPE` → `EUR`). Userbase zone columns used when tool has no zone.

---

## 1. Application Security (`appSec`)

| | |
|---|---|
| **Inputs** | Tool export only |
| **LMS name** | Introduction to Application Security #ABI |

### Steps

1. Parse tool file (header detection above).
2. For each tool row (after dedupe):
   - Read Employee ID, Work Email, Zone, Transcript Status, Training Start Date, Transcript Completed Date.
   - **Training Start Date:** use LMS start date; if status is not Completed and **Assignment Date** is set, use Assignment Date when start is empty.
   - Map status (see shared rules).
3. Split preview/download rows by **Training Start Date** year → tabs 2024 / 2025 / 2026.
4. **Metrics:** Total = row count; Completed = status Completed; Pending = rest.

### Output columns

`Employee ID`, `Work Email Address`, `Zone`, `Transcript Status`, `Training Start Date`, `Transcript Completed Date`

---

## 2. Cyber OT (`cyberOT`)

Same steps as **Application Security** (tool-only). LMS name: **Cyber OT Training #ABI**.

---

## 3. Growth Group (`growth`)

| | |
|---|---|
| **Inputs** | Tool export only |
| **Pre-filter** | **Macro entity level three BU Description** = `GLOBAL GROWTH` |

### Steps

1. Parse tool file.
2. **Keep only rows** where BU column (case/spacing insensitive) equals `GLOBAL GROWTH`; count excluded rows for the toast message.
3. Apply the same tool-only processing as App Sec on the filtered rows.
4. Year tabs and metrics as App Sec.

---

## 4. New Joiner (`newJoiner`)

| | |
|---|---|
| **Inputs** | Tool export only |
| **Special column** | **New J original hire date** (typo *orginal* also accepted) |

### Steps

1. Parse tool file.
2. Require hire-date column; error if missing.
3. For each deduped tool row:
   - **Training Start Date** = formatted **original hire date** (not LMS training start).
   - Status and completion from tool as usual.
4. Year tabs bucket rows by **Training Start Date** (hire date), not LMS start.

---

## 5. BSC (`bsc`)

| | |
|---|---|
| **Inputs** | **Userbase** + tool export |
| **Match keys** | Emp ID and/or email |
| **Output** | Full userbase + 3 appended columns |

### Steps

1. Parse **userbase** and **tool** files.
2. Walk **every userbase row** (dedupe by email or Emp ID for processing).
3. Find **all tool rows** matching that user (by email or ID).
4. For matched users, use the **latest tool row by Training Start Date** (single rule even if multiple rows exist):
   - If status Completed → Completed and copy completion date.
   - If Assignment Date **after** existing start date → status **Reassigned**, start = Assignment Date, clear completion.
   - Else use LMS status/start, or Not Started + Assignment Date.

5. **Do not change** original userbase start-date columns.
6. **Append** after last filled userbase header:
   - `start date_extracted`
   - `Training completion date`
   - `training completion status`
7. Year tabs use **`start date_extracted`**.
8. **Metrics:** total userbase rows processed; completed = appended status Completed; pending = not completed.
9. **Download:** single sheet **Userbase** with all original + appended columns.

---

## 6. Phishing Normal (`phishingNormal`)

| | |
|---|---|
| **Inputs** | **Phishing Tracking Input** (userbase) + tool export |
| **In-scope rows** | All uploaded userbase rows |
| **Match** | Emp ID + email |

### Steps

1. Parse userbase and tool.
2. For **each userbase row**:
   - Copy all original columns.
   - If already seen (duplicate email/ID) → skip duplicate for KPIs (same as dedupe).
   - Match tool by email or Emp ID:
     - **Found:** map status (Completed / In Progress / Not Started / etc.), LMS start → `Training Start Date`, LMS completion → `Training completion date`, status → `training completion status`.
     - **Not found:** status = **Not Found**; dates empty.
3. **Append** after last filled header: `Training Start Date`, `Training completion date`, `training completion status`.
4. **Metrics (deduped uploaded rows):**
   - **Total** = uploaded unique users
   - **Completed** / **Not completed** / **Not found**
5. **Download:** full updated userbase (one sheet). **Pending download:** uploaded rows where status ≠ Completed.

---

## 7. Band 4+ Senior Management (`band4`)

| | |
|---|---|
| **Inputs** | Phishing Tracking Input + tool export |
| **In-scope rows** | All uploaded userbase rows |

Band 4+ uses the same enrichment shape (append 3 columns) and treats uploaded userbase as already filtered.

---

## Assignment Date

Used when:

- Tool-only trainings need a start date for non-completed rows.
- BSC reassignment / default start logic.
- Phishing Normal / Band 4+ when LMS training start is missing but user was found in tool.

Default in the dashboard: **today’s date** (editable per tab).

---

## Files reference

| File | Role |
|------|------|
| `dashboard/index.html` | UI — open directly in browser |
| `shared/javascript/app.js` | In-browser calculations |
| `tool/run_calculation.py` | CLI entry point |
| `shared/python/dashboard_calculators.py` | Python calculations |
| `shared/python/run_database.py` | Run history in SQLite |
| `shared/python/completion_state.py` | Completion date persistence (CLI legacy exports) |
| `data/training_status.db` | Created on first Python run |

---

## Legacy note

The Flask upload server (`server/upload_server.py`, `scripts/start_server.ps1`) is **optional** and no longer required. The dashboard works fully offline via `file://`.
