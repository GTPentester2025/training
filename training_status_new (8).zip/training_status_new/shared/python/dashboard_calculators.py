"""
Dashboard calculation logic (mirrors shared/javascript/app.js).

Each function returns (output_dataframe, metrics_dict).
Userbase trainings write all original columns plus appended fields.
"""

from __future__ import annotations

import re
from datetime import date, datetime
from typing import Any, Callable, Optional

import pandas as pd

from excel_io import load_tool_excel, load_userbase_excel
from training_processor import _find_column, _norm_id, _norm_key, map_macro_zone, map_transcript_status

BSC_APPEND = [
    "start date_extracted",
    "Training completion date",
    "training completion status",
]
TRACKING_APPEND = [
    "Training Start Date",
    "Training completion date",
    "training completion status",
]

OUTPUT_COLS = [
    "Employee ID",
    "Work Email Address",
    "Zone",
    "Transcript Status",
    "Training Start Date",
    "Transcript Completed Date",
]


def _norm(s: object) -> str:
    return _norm_key(s).lower()


def _fmt_date(val: object) -> str:
    if val is None or (isinstance(val, float) and pd.isna(val)):
        return ""
    if isinstance(val, pd.Timestamp):
        if pd.isna(val):
            return ""
        return val.strftime("%d/%m/%Y")
    if isinstance(val, datetime):
        return val.strftime("%d/%m/%Y")
    if isinstance(val, date):
        return val.strftime("%d/%m/%Y")
    s = str(val).strip()
    if not s:
        return ""
    ts = pd.to_datetime(s, errors="coerce", dayfirst=True)
    if pd.isna(ts):
        return s
    return ts.strftime("%d/%m/%Y")


def _derive_status(raw_status: str, completed_date: str) -> str:
    if completed_date and str(completed_date).strip():
        return "Completed"
    raw = str(raw_status or "").strip()
    if re.search(r"in progress", raw, re.I):
        return "In Progress"
    if raw:
        return raw
    return "Not Started"


def _find_col(df: pd.DataFrame, exact: list[str], *patterns: str) -> Optional[str]:
    for name in exact:
        c = _find_column(df, name)
        if c:
            return c
    for pat in patterns:
        rx = re.compile(pat, re.I)
        for c in df.columns:
            if rx.search(str(c)):
                return c
    return None


def _tool_cols(df: pd.DataFrame) -> dict[str, Optional[str]]:
    return {
        "id": _find_col(df, ["Employee ID"], r"^employee\s*id$", r"employee.?id|emp.?id"),
        "email": _find_col(
            df, ["Work Email Address"], r"^work\s*email", r"work.?email|email.?address"
        ),
        "status": _find_col(df, ["Transcript Status"], r"transcript.?status"),
        "start": _find_col(df, ["Training Start Date"], r"training.?start"),
        "complete": _find_col(
            df,
            ["Transcript Completed Date", "Transcript Completion Date", "Completion Date"],
            r"transcript.?completed|completion.?date",
        ),
        "zone": _find_col(
            df, ["Macro Entity Level 2 (Zone)", "Zone"], r"macro.?entity.?level.?2", r"^zone$"
        ),
        "bu3": _find_col(
            df,
            [
                "Macro entity level three BU Description",
                "Macro Entity Level 3 (BU Description)",
                "Macro Entity Level 3 BU Description",
            ],
            r"macro.?entity.?level.?three.*bu",
            r"macro.?entity.?level.?3.*bu",
            r"macro.?entity.?level.?3",
        ),
        "hire": _find_col(
            df,
            [
                "New J orginal hire date",
                "New J original hire date",
                "New Joiner Original Hire Date",
                "Original Hire Date",
            ],
            r"new\s*j\s*orginal\s*hire",
            r"new\s*j\s*original\s*hire",
            r"original\s*hire\s*date",
        ),
    }


def _last_real_header_index(headers: list[str]) -> int:
    last = -1
    for i, h in enumerate(headers):
        if str(h).strip() and not str(h).startswith("__col_"):
            last = i
    return last


def _append_columns(headers: list[str], append: list[str]) -> list[str]:
    out = headers[: _last_real_header_index(headers) + 1]
    seen = {str(h).strip().lower() for h in out}
    for col in append:
        if col.lower() not in seen:
            out.append(col)
            seen.add(col.lower())
    return out


def _build_lookup(df: pd.DataFrame, email_col: Optional[str], id_col: Optional[str]) -> dict[str, dict]:
    lookup: dict[str, dict] = {}
    for _, row in df.iterrows():
        d = row.to_dict()
        if email_col:
            e = _norm(row.get(email_col))
            if e:
                lookup[e] = d
        if id_col:
            i = _norm_id(row.get(id_col))
            if i:
                lookup[i] = d
    return lookup


def _find_match(lookup: dict[str, dict], email: str, emp_id: str) -> Optional[dict]:
    if email:
        r = lookup.get(_norm(email))
        if r:
            return r
    if emp_id:
        r = lookup.get(_norm_id(emp_id))
        if r:
            return r
    return None


def _tool_rows_for_user(
    tool_df: pd.DataFrame, cols: dict, email: str, emp_id: str
) -> list[dict]:
    seen: set[str] = set()
    out: list[dict] = []
    for _, row in tool_df.iterrows():
        r_email = _norm(row.get(cols["email"])) if cols["email"] else ""
        r_id = _norm_id(row.get(cols["id"])) if cols["id"] else ""
        match = (email and r_email == _norm(email)) or (emp_id and r_id == _norm_id(emp_id))
        if not match:
            continue
        sig = f"{r_id}|{r_email}"
        if sig in seen:
            continue
        seen.add(sig)
        out.append(row.to_dict())
    return out


def _parse_date_for_compare(s: str) -> Optional[datetime]:
    if not s:
        return None
    parts = str(s).split("/")
    if len(parts) == 3:
        try:
            return datetime(int(parts[2]), int(parts[1]), int(parts[0]))
        except ValueError:
            pass
    ts = pd.to_datetime(s, errors="coerce", dayfirst=True)
    if pd.isna(ts):
        return None
    return ts.to_pydatetime()


def _resolve_bsc_training(tool_rows: list[dict], cols: dict, assign_date: str) -> dict[str, str]:
    status = "Not Started"
    start_extracted = assign_date or ""
    completed = ""

    if not tool_rows:
        return {
            "status": status,
            "start_date_extracted": start_extracted,
            "completed_date": completed,
        }

    # Multiple matches: use the latest training-start row only.
    row = max(
        tool_rows,
        key=lambda r: _parse_date_for_compare(_fmt_date(r.get(cols["start"]))) or datetime.min,
    )
    existing_status = str(row.get(cols["status"]) or "").strip()
    existing_start = _fmt_date(row.get(cols["start"]))
    needs_new = False

    if _norm(existing_status) == "completed":
        status = "Completed"
        start_extracted = existing_start
        completed = _fmt_date(row.get(cols["complete"]))
        needs_new = True
    elif existing_status:
        status = existing_status
        start_extracted = existing_start
    else:
        status = "Not Started"
        start_extracted = assign_date or ""

    if needs_new and assign_date and existing_start:
        new_d = _parse_date_for_compare(assign_date)
        ex_d = _parse_date_for_compare(existing_start)
        if new_d and ex_d and new_d > ex_d:
            status = "Reassigned"
            start_extracted = assign_date
            completed = ""

    return {
        "status": status,
        "start_date_extracted": start_extracted,
        "completed_date": completed,
    }


def _make_output_rows(tool_df: pd.DataFrame, cols: dict, assign_date: str) -> pd.DataFrame:
    rows = []
    seen: set[str] = set()
    for _, tr in tool_df.iterrows():
        emp_id = tr.get(cols["id"])
        email = tr.get(cols["email"])
        key = _norm_id(str(emp_id or "")) or _norm(email)
        if key and key in seen:
            continue
        if key:
            seen.add(key)
        raw_status = str(tr.get(cols["status"]) or "").strip()
        completed_date = _fmt_date(tr.get(cols["complete"]))
        start_date = _fmt_date(tr.get(cols["start"]))
        if _norm(raw_status) != "completed" and assign_date and not start_date:
            start_date = _fmt_date(assign_date)
        zone = tr.get(cols["zone"]) if cols["zone"] else ""
        status = _derive_status(raw_status, completed_date)
        rows.append(
            {
                "Employee ID": _norm_id(emp_id) or str(emp_id or "").strip(),
                "Work Email Address": str(email or "").strip(),
                "Zone": map_macro_zone(zone) or str(zone or "").strip(),
                "Transcript Status": status,
                "Training Start Date": start_date,
                "Transcript Completed Date": completed_date,
            }
        )
    return pd.DataFrame(rows, columns=OUTPUT_COLS)


def _metrics_from_output(df: pd.DataFrame, status_col: str = "Transcript Status") -> dict[str, Any]:
    total = len(df)
    completed = sum(1 for s in df[status_col].astype(str) if _norm(s) == "completed")
    return {
        "total": total,
        "completed": completed,
        "pending": total - completed,
        "not_found": 0,
    }


def calculate_app_sec(tool_path, assign_date: str = "") -> tuple[pd.DataFrame, dict]:
    tool_df = load_tool_excel(tool_path)
    cols = _tool_cols(tool_df)
    out = _make_output_rows(tool_df, cols, assign_date)
    return out, _metrics_from_output(out)


def calculate_cyber_ot(tool_path, assign_date: str = "") -> tuple[pd.DataFrame, dict]:
    return calculate_app_sec(tool_path, assign_date)


def calculate_growth(tool_path, assign_date: str = "") -> tuple[pd.DataFrame, dict]:
    tool_df = load_tool_excel(tool_path)
    cols = _tool_cols(tool_df)
    if not cols["bu3"]:
        raise ValueError('Missing column "Macro entity level three BU Description"')
    bu = tool_df[cols["bu3"]].astype(str).str.strip().str.upper().str.replace(r"\s+", " ", regex=True)
    filtered = tool_df.loc[bu == "GLOBAL GROWTH"].copy()
    out = _make_output_rows(filtered, cols, assign_date)
    m = _metrics_from_output(out)
    m["excluded"] = len(tool_df) - len(filtered)
    m["total_in_file"] = len(tool_df)
    return out, m


def calculate_new_joiner(tool_path, assign_date: str = "") -> tuple[pd.DataFrame, dict]:
    tool_df = load_tool_excel(tool_path)
    cols = _tool_cols(tool_df)
    if not cols["hire"]:
        raise ValueError('Missing column "New J original hire date" (or similar)')
    rows = []
    seen: set[str] = set()
    for _, tr in tool_df.iterrows():
        emp_id = tr.get(cols["id"])
        email = tr.get(cols["email"])
        key = _norm_id(str(emp_id or "")) or _norm(email)
        if key and key in seen:
            continue
        if key:
            seen.add(key)
        hire = _fmt_date(tr.get(cols["hire"]))
        raw_status = str(tr.get(cols["status"]) or "").strip()
        completed_date = _fmt_date(tr.get(cols["complete"]))
        start_date = hire or _fmt_date(tr.get(cols["start"])) or ""
        zone = tr.get(cols["zone"]) if cols["zone"] else ""
        status = _derive_status(raw_status, completed_date)
        rows.append(
            {
                "Employee ID": _norm_id(emp_id) or str(emp_id or "").strip(),
                "Work Email Address": str(email or "").strip(),
                "Zone": map_macro_zone(zone) or str(zone or "").strip(),
                "Transcript Status": status,
                "Training Start Date": start_date,
                "Transcript Completed Date": completed_date,
            }
        )
    out = pd.DataFrame(rows, columns=OUTPUT_COLS)
    return out, _metrics_from_output(out)


def _resolve_base_id_email(base_df: pd.DataFrame) -> tuple[Optional[str], Optional[str]]:
    id_col = _find_col(
        base_df, ["Emp ID", "Local Employee ID", "Employee ID"], r"emp.?id", r"local.?id"
    )
    email_col = _find_col(base_df, ["Employee Email", "Email - Primary Work"], r"email")
    return id_col, email_col


def _enrich_userbase_tracking(
    base_df: pd.DataFrame,
    tool_df: pd.DataFrame,
    assign_date: str,
    in_scope: Callable[[dict], bool],
) -> tuple[pd.DataFrame, pd.DataFrame, dict]:
    id_col, email_col = _resolve_base_id_email(base_df)
    cols = _tool_cols(tool_df)
    lookup = _build_lookup(tool_df, cols["email"], cols["id"])
    zone_col = _find_col(base_df, ["Zone", "Macro Entity Level 2 (Zone)"], r"^zone$", r"macro.?entity.?level.?2")

    headers = _append_columns(list(base_df.columns.astype(str)), TRACKING_APPEND)
    enriched_rows: list[dict] = []
    stats_rows: list[dict] = []
    seen: set[str] = set()
    completed = not_completed = not_found = 0

    for _, base_row in base_df.iterrows():
        row_dict = {str(k): base_row[k] for k in base_df.columns}
        enriched = {h: "" for h in headers}
        enriched.update(row_dict)

        if not in_scope(row_dict):
            enriched_rows.append(enriched)
            continue

        base_email = str(row_dict.get(email_col) or "").strip() if email_col else ""
        base_id = str(row_dict.get(id_col) or "").strip() if id_col else ""
        dedupe = _norm(base_email) or _norm_id(base_id)
        if not dedupe:
            enriched_rows.append(enriched)
            continue
        if dedupe in seen:
            continue
        seen.add(dedupe)

        tool_row = _find_match(lookup, base_email, base_id)
        if tool_row:
            raw_status = str(tool_row.get(cols["status"]) or "").strip()
            completed_date = _fmt_date(tool_row.get(cols["complete"]))
            start_date = _fmt_date(tool_row.get(cols["start"])) or assign_date or ""
            zone = tool_row.get(cols["zone"]) if cols["zone"] else ""
            if not zone and zone_col:
                zone = row_dict.get(zone_col)
            status = _derive_status(raw_status, completed_date)
        else:
            status = "Not Found"
            start_date = completed_date = ""

        enriched["Training Start Date"] = start_date
        enriched["Training completion date"] = completed_date
        enriched["training completion status"] = status
        enriched_rows.append(enriched)
        stats_rows.append(enriched)

        o = _norm(status)
        if o == "completed":
            completed += 1
        elif o == "not found":
            not_found += 1
        else:
            not_completed += 1

    out = pd.DataFrame(enriched_rows, columns=headers)
    stats_df = pd.DataFrame(stats_rows, columns=headers) if stats_rows else pd.DataFrame(columns=headers)
    metrics = {
        "total": len(stats_rows),
        "completed": completed,
        "pending": not_completed + not_found,
        "not_completed": not_completed,
        "not_found": not_found,
        "userbase_rows": len(enriched_rows),
    }
    return out, stats_df, metrics


def _in_phishing_normal_scope(row: dict) -> bool:
    # User uploads already-filtered data for Phishing Normal.
    return True


def _in_band4_scope(row: dict) -> bool:
    # User uploads already-filtered data for Band 4+.
    return True


def calculate_phishing_normal(base_path, tool_path, assign_date: str = "") -> tuple[pd.DataFrame, dict]:
    base_df = load_userbase_excel(base_path)
    tool_df = load_tool_excel(tool_path)
    out, _, metrics = _enrich_userbase_tracking(base_df, tool_df, assign_date, _in_phishing_normal_scope)
    return out, metrics


def calculate_band4(base_path, tool_path, assign_date: str = "") -> tuple[pd.DataFrame, dict]:
    base_df = load_userbase_excel(base_path)
    tool_df = load_tool_excel(tool_path)
    out, _, metrics = _enrich_userbase_tracking(base_df, tool_df, assign_date, _in_band4_scope)
    return out, metrics


def calculate_bsc(base_path, tool_path, assign_date: str = "") -> tuple[pd.DataFrame, dict]:
    base_df = load_userbase_excel(base_path)
    tool_df = load_tool_excel(tool_path)
    id_col, email_col = _resolve_base_id_email(base_df)
    cols = _tool_cols(tool_df)
    zone_col = _find_col(base_df, ["Zone", "Macro Entity Level 2 (Zone)"], r"^zone$", r"macro.?entity.?level.?2")

    headers = _append_columns(list(base_df.columns.astype(str)), BSC_APPEND)
    enriched_rows: list[dict] = []
    seen: set[str] = set()
    matched = 0

    for _, base_row in base_df.iterrows():
        row_dict = {str(k): base_row[k] for k in base_df.columns}
        base_email = str(row_dict.get(email_col) or "").strip() if email_col else ""
        base_id = str(row_dict.get(id_col) or "").strip() if id_col else ""
        dedupe = _norm(base_email) or _norm_id(base_id)
        if not dedupe or dedupe in seen:
            continue
        seen.add(dedupe)

        tool_rows = _tool_rows_for_user(tool_df, cols, base_email, base_id)
        if tool_rows:
            matched += 1
        training = _resolve_bsc_training(tool_rows, cols, assign_date)

        zone = str(row_dict.get(zone_col) or "").strip() if zone_col else ""
        if not zone and tool_rows:
            zone = str(tool_rows[0].get(cols["zone"]) or "")

        enriched = {h: "" for h in headers}
        enriched.update(row_dict)
        enriched["start date_extracted"] = training["start_date_extracted"]
        enriched["Training completion date"] = training["completed_date"]
        enriched["training completion status"] = training["status"]
        enriched_rows.append(enriched)

    out = pd.DataFrame(enriched_rows, columns=headers)
    status_col = "training completion status"
    completed = sum(1 for r in enriched_rows if _norm(r.get(status_col)) == "completed")
    metrics = {
        "total": len(enriched_rows),
        "completed": completed,
        "pending": len(enriched_rows) - completed,
        "not_found": 0,
        "matched": matched,
        "userbase_rows": len(enriched_rows),
    }
    return out, metrics


TRAINING_CALCULATORS = {
    "app_sec": ("application_security", calculate_app_sec, False),
    "application_security": ("application_security", calculate_app_sec, False),
    "cyber_ot": ("cyber_ot", calculate_cyber_ot, False),
    "growth": ("growth_group", calculate_growth, False),
    "growth_group": ("growth_group", calculate_growth, False),
    "new_joiner": ("new_joiner", calculate_new_joiner, False),
    "bsc": ("bsc", calculate_bsc, True),
    "phishing_normal": ("phishing_normal", calculate_phishing_normal, True),
    "phishingNormal": ("phishing_normal", calculate_phishing_normal, True),
    "band4": ("band4_senior_management", calculate_band4, True),
    "band4_senior_management": ("band4_senior_management", calculate_band4, True),
}
