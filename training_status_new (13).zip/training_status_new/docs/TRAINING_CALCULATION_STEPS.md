# Training calculation steps

This document describes **exactly** what happens when you click **Calculate** in the HTML dashboard (`dashboard/index.html`) or run the Python tool (`tool/run_calculation.py`). Both use the same rules (JavaScript in `shared/javascript/app.js`, Python in `shared/python/dashboard_calculators.py`).

## How to run (no localhost required)

### Option A — HTML dashboard (browser only)

1. Open **`dashboard/index.html`** in Chrome or Edge (double-click or drag into the browser).
2. On each tab, upload the Excel file(s) for that training.
3. Set **Assignment Date** if the training uses it.
4. Click **Calculate**.
5. Use **Download Updated Userbase** (userbase trainings) or **Download Excel** (tool-only trainings).

Files stay in the browser memory unless you download the result. Nothing is uploaded to a server.

### Option B — Python + SQLite (CLI)

```powershell
cd c:\Users\manka\Downloads\training_status_new
pip install -r requirements.txt

# List trainings
python tool/run_calculation.py --list

# Example: BSC
python tool/run_calculation.py bsc ^
  --base trainings\bsc\input\userbase.xlsx ^
  --tool trainings\bsc\input\BSC.xlsx ^
  --assign-date 2026-05-29

# View run history
python tool/run_calculation.py --history
```

- **Output Excel:** `trainings/<module>/output/<module>_Updated_Userbase_YYYY-MM-DD.xlsx` (or `_Output_` for tool-only).
- **SQLite:** `data/training_status.db`
  - Table **`calculation_runs`** — each CLI run (counts, file paths, timestamp).
  - Table **`completion_records`** — used by legacy CLI scripts for inferred completion dates when LMS date is missing.

---

## Shared preprocessing (all trainings)

| Step | Action |
|------|--------|
| 1 | Read the **first worksheet** of each uploaded `.xlsx`. |
| 2 | **Tool / LMS file:** find the header row containing **Employee ID**, **Transcript Status**, and **Work Email Address** (usually Excel row 22; scanned up to ~35 rows). |
| 3 | **Userbase file:** find the first row with both an **email** column and an **employee id** column (header usually row 1). |
| 4 | Drop rows where **Employee Status** = `Terminated` (if that column exists). |
| 5 | **Deduplicate** output rows by normalized email, else by normalized employee ID (first row wins). |

**Normalization:** emails → lowercase trim; employee IDs → trim, strip trailing `.0` from Excel numbers.

**Status mapping (tool rows):**

- If completion date is present → **Completed**
- Else if transcript status contains “in progress” → **In Progress**
- Else use LMS transcript status, or **Not Started** if empty

**Zone:** from tool **Macro Entity Level 2 (Zone)** or **Zone**, normalized to **MAZ / EUR / APAC / AFR / SAZ / NAZ / Global Core** (accepts long names like `ZONE EUROPE`, short codes like `EUR`, and common variants). Userbase zone columns used when tool has no zone.

---

## 1. Application Security (`appSec`)

| | |
|---|---|
| **Inputs** | Tool export only |
| **LMS name** | Introduction to Application Security #ABI |

### Steps

1. Parse tool file (header detection above).
2. For each tool row (after dedupe):
   - Read Employee ID, Work Email, Zone, Transcript Status, Training Start Date, Transcript Completed Date.
   - **Training Start Date:** use LMS start date; if status is not Completed and **Assignment Date** is set, use Assignment Date when start is empty.
   - Map status (see shared rules).
3. Split preview/download rows by **Training Start Date** year → tabs 2024 / 2025 / 2026.
4. **Metrics:** Total = row count; Completed = status Completed; Pending = rest.

### Output columns

`Employee ID`, `Work Email Address`, `Zone`, `Transcript Status`, `Training Start Date`, `Transcript Completed Date`

---

## 2. Cyber OT (`cyberOT`)

Same steps as **Application Security** (tool-only). LMS name: **Cyber OT Training #ABI**.

---

## 3. Growth Group (`growth`)

| | |
|---|---|
| **Inputs** | Tool export only |
| **Pre-filter** | **Macro Entity Level 3 (BU) Description** = `GLOBAL GROWTH` |
| **Zone source** | **Macro Entity Level 3 (BU) Description** only (not Macro Entity Level 2) |

### Steps

1. Parse tool file.
2. **Keep only rows** where BU column (case/spacing insensitive) equals `GLOBAL GROWTH`; count excluded rows for the toast message.
3. Apply the same tool-only processing as App Sec on the filtered rows, but **Zone** = value from **Macro Entity Level 3 (BU) Description** (raw text, no Macro Level 2 mapping).
4. Year tabs and metrics as App Sec.

---

## 4. New Joiner (`newJoiner`)

| | |
|---|---|
| **Inputs** | Tool export only |
| **Special column** | **`Original Hire Date`** (required) |
| **Year scope** | Hire years **2024, 2025, 2026** only — all other years excluded |
| **Terminated** | Rows with **Employee Status = Terminated** removed at parse |

### Steps

1. Parse **entire** tool sheet (full used range); exclude terminated rows.
2. Require **`Original Hire Date`**; error if missing.
3. Normalize hire date to **dd/mm/yyyy**; assign year tab from calendar year (2024 / 2025 / 2026 only).
4. For each deduped user (email/ID + hire-year):
   - **Training Start Date** (output) = normalized **Original Hire Date**
   - Status, completion, zone from tool (Growth subset when Global + GLOBAL GROWTH BU)
5. Large files use parallel workers (CPU cores − 2) after a fast prep pass.

---

## 5. BSC (`bsc`)

| | |
|---|---|
| **Inputs** | **Userbase** + tool export |
| **Match keys** | Emp ID and/or email |
| **Output** | Full userbase + 3 appended columns |

### Steps

1. Parse **userbase** and **tool** files.
2. **Userbase is the master list** — walk **every userbase row** and append training fields.
3. **Total KPI** = unique userbase users (dedupe by Emp ID + email); duplicate rows still appear in download with the same mapping.
4. For each userbase row with Emp ID or email, match **tool** by email or ID:
   - **Found:** map status and completion from the **latest tool row by Training Start Date**.
   - **Not found in tool:** status **Not Found**; **`start date_extracted`** = Assignment Date.
5. **`start date_extracted`** = **Assignment Date** (year tabs / zone tiles).

6. **Do not change** original userbase start-date columns.
7. **Append** after last filled userbase header:
   - `start date_extracted`
   - `Training completion date`
   - `training completion status`
8. Year tabs and current-year zone/center tiles use **`start date_extracted`** on **unique userbase users**.
9. **Metrics:** Total = unique userbase; Completed / Pending (includes Not Found).
10. **Download:** all userbase rows with appended columns.

---

## 6. Phishing Normal (`phishingNormal`)

| | |
|---|---|
| **Inputs** | **Phishing Tracking Input** (userbase) + tool export |
| **In-scope rows** | All uploaded userbase rows |
| **Match** | **Employee Email**, **Global Employee ID**, **Local Employee ID** → tool **Work Email Address** / **Employee ID** |

### Steps

1. Parse userbase and tool.
2. **Userbase is the master list** — every row kept in download; **Total KPI** = unique userbase users.
3. For each userbase row, match tool using **Employee Email**, **Global Employee ID**, or **Local Employee ID** (any hit counts):
   - **Found:** map status, dates from tool.
   - **Not found:** status **Not Found**; dates empty.
   - Duplicate keys in userbase: same mapping applied; counted once in Total KPI.
4. **Append** after last filled header: `Training Start Date`, `Training completion date`, `training completion status`.
5. **Metrics (unique userbase):** Total, Completed, Not completed, Not found.
6. **Download:** full updated userbase (all rows).

---

## 7. Band 4+ Senior Management (`band4`)

| | |
|---|---|
| **Inputs** | Phishing Tracking Input + tool export |
| **In-scope rows** | All uploaded userbase rows |
| **Match** | Same as Phishing Normal: **Employee Email**, **Global Employee ID**, **Local Employee ID** |

Same steps as Phishing Normal (append 3 columns; uploaded userbase is already filtered), except:

- **`Training Start Date`** (appended) = **Assignment Date** for matched users — used for year tabs and current-year zone tiles (not LMS training start).
- Status and completion date still come from the tool match.

---

## Assignment Date

Used when:

- Tool-only trainings need a start date for non-completed rows.
- **BSC** and **Band 4+**: **`start date_extracted` / `Training Start Date`** = Assignment Date (year filtering).
- **Phishing Normal** when LMS training start is missing but user was found in tool.

Default in the dashboard: **today’s date** (editable per tab).

---

## Files reference

| File | Role |
|------|------|
| `dashboard/index.html` | UI — open directly in browser |
| `shared/javascript/app.js` | In-browser calculations |
| `tool/run_calculation.py` | CLI entry point |
| `shared/python/dashboard_calculators.py` | Python calculations |
| `shared/python/run_database.py` | Run history in SQLite |
| `shared/python/completion_state.py` | Completion date persistence (CLI legacy exports) |
| `data/training_status.db` | Created on first Python run |

---

## Legacy note

The Flask upload server (`server/upload_server.py`, `scripts/start_server.ps1`) is **optional** and no longer required. The dashboard works fully offline via `file://`.
