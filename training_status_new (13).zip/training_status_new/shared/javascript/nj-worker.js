/** Web Worker: build New Joiner output rows from pre-parsed slice (no dedupe across slices). */
(function () {
  function processSlice(slice) {
    const result = { '2024': [], '2025': [], '2026': [] };
    for (let i = 0; i < slice.length; i++) {
      const p = slice[i];
      const tab = p.hireYearTab;
      if (!tab || !result[tab]) continue;
      const outRow = {
        'Employee ID': p.empId || '',
        'Work Email Address': p.email || '',
        'Zone': p.zone || '',
        'Transcript Status': p.status || '',
        'Training Start Date': p.startDate || '',
        'Transcript Completed Date': p.completedDate || '',
        _hireDate: p.startDate || '',
      };
      result[tab].push(outRow);
    }
    return { result };
  }

  self.onmessage = function (e) {
    self.postMessage(processSlice(e.data.slice || []));
  };
})();
